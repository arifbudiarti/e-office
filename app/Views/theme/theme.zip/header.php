<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>E-OFFICE | <?= $title ?></title>
    <!-- icon -->
    <link rel="icon" href="<?= base_url(); ?>/assets/img/nsm_potrait.png" type="image/x-icon" />
    <!-- css -->
    <link href="<?= base_url(); ?>/assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="<?= base_url(); ?>/assets/font-awesome/css/font-awesome.css" rel="stylesheet">
    <!-- Morris -->
    <link href="<?= base_url(); ?>/assets/css/plugins/morris/morris-0.4.3.min.css" rel="stylesheet">
    <link href="<?= base_url(); ?>/assets/css/animate.css" rel="stylesheet">
    <link href="<?= base_url(); ?>/assets/css/style.css" rel="stylesheet">
    <!-- Datatables -->
    <link href="<?= base_url(); ?>/assets/css/plugins/dataTables/datatables.min.css" rel="stylesheet">
    <!-- Chosen -->
    <link href="<?= base_url(); ?>/assets/css/plugins/chosen/bootstrap-chosen.css" rel="stylesheet">
</head>