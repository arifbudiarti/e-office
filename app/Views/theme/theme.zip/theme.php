<?php echo view('theme/header'); ?>
<?php echo view('theme/sidebar'); ?>
<?php echo view('theme/topbar'); ?>
<?= $this->renderSection('content') ?>
<?php echo view('theme/footer'); ?>