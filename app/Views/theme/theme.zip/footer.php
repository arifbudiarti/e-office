 <div class="footer">
     <div class="float-right">
         10GB of <strong>250GB</strong> Free.
     </div>
     <div>
         <strong>Copyright</strong> Example Company &copy; 2014-2018
     </div>
 </div>
 </div>
 </div>

 <!-- Mainly scripts -->
 <script src="<?= base_url(); ?>/assets/js/jquery-3.1.1.min.js"></script>
 <script src="<?= base_url(); ?>/assets/js/popper.min.js"></script>
 <script src="<?= base_url(); ?>/assets/js/bootstrap.js"></script>
 <script src="<?= base_url(); ?>/assets/js/plugins/metisMenu/jquery.metisMenu.js"></script>
 <script src="<?= base_url(); ?>/assets/js/plugins/slimscroll/jquery.slimscroll.min.js"></script>
 <!-- Chosen -->
 <script src="<?= base_url(); ?>/assets/js/plugins/chosen/chosen.jquery.js"></script>
 <!-- Custom and plugin javascript -->
 <script src="<?= base_url(); ?>/assets/js/inspinia.js"></script>
 <script src="<?= base_url(); ?>/assets/js/plugins/pace/pace.min.js"></script>
 <!-- jQuery UI -->
 <script src="<?= base_url(); ?>/assets/js/plugins/jquery-ui/jquery-ui.min.js"></script>
 <!-- dataTables  -->
 <script src="<?= base_url(); ?>/assets/js/plugins/dataTables/datatables.min.js"></script>
 <script src="<?= base_url(); ?>/assets/js/plugins/dataTables/dataTables.bootstrap4.min.js"></script>

 <script type="text/javascript">
     $('.chosen-select').chosen({
         width: "100%"
     });
 </script>

 </body>

 </html>